# Aircraft-Speed-Sensor
Repository ini adalah bentuk implementasi arsitektur sebuah rancangan sensor kecepatan pesawat. Dibuat untuk memenuhi tugas project matakuliah APL 2020
