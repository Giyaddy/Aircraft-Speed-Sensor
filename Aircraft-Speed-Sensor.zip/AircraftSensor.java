
/**
 * Write a description of interface AircraftSensor here.
 * 
 * @author (M. Hilal Mubarrak) 
 * @version (a version number or a date)
 */
public interface AircraftSensor
{
    public void showDataInfo();
    public Aircraft sendToController();
}