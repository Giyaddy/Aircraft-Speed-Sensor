
/**
 * Write a description of interface WindSensor here.
 * 
 * @author (M. Hilal Mubarrak) 
 * @version (a version number or a date)
 */
public interface WindSensor{
    
    public void showDataInfo();
    public Wind sendToController();
}
